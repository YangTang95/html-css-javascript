<?php
//$server = '127.0.0.1';
//$user = "root";
$db = new PDO('mysql:host=localhost;dbname=info153_mysql', 'root');

//$connect=mysqli_connect("localhost","root",""," info153_mysql");
//$pass = 'myPass';
//$dbname = 'info153_mysql';
//$con = mysql_connect($server, $user) or die("Can't connect");
//mysql_select_db($dbname);
//'mysql:host=localhost;dbname=info153_mysql', 
//$jsondata=file_get_contents($TweetType1);
$data=json_decode($TweetType1,true);
$stmt=$db->prepare("insert into json values(?,?,?)");

foreach($data as $row){
	$stmt-bindParam(1,$row['User_name']);
	$stmt-bindParam(2,$row['Tweet']);
	$stmt-bindParam(3,$row['Follower_count']);
}
?>
