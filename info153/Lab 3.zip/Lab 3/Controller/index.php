<?php
require("../model/database.php");
require("../model/employee_db.php");
$myTable = get_table();
include("../view/ShowData.php");
//include("../view/testList.php");
?>

