<h1>Employee Data</h1>
<table border = 1>
	<?php
                echo "<tr><th>NUM</th><th>NUM2</th><tr>";
                foreach($myTable as $row) {
                    echo "<tr><td>" . $row["HC01_MOE_VC01"]. "</td><td>" . $row["HC02_MOE_VC20"]."</td><tr>";
                }
	?>
</table>

